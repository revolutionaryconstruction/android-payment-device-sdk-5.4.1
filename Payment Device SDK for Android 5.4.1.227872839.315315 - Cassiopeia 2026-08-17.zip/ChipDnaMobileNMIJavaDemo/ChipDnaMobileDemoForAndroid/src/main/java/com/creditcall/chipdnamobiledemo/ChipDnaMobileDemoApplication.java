package com.creditcall.chipdnamobiledemo;

import com.creditcall.chipdnamobile.ChipDnaApplication;

// TODO: Enable TTM
// Create a custom Application class that extends ChipDnaApplication, and register it in the
// <application android:name=".ChipDnaMobileDemoApplication"> tag in the AndroidManifest.
//
// Extending ChipDnaApplication wires the Cloud Commerce SDK for you. The environment is bound at
// startup and defaults to Production (ParameterValues.LiveEnvironment). Override getEnvironment()
// to run against Test/MTF - pass the same value you later set for ParameterKeys.Environment via
// setProperties, so routing and ChipDNA's live/test mode agree. (On the sandbox-only debug build,
// a LIVE request falls back to Sandbox automatically.)
//
// public class ChipDnaMobileDemoApplication extends ChipDnaApplication {
//
//     // Select the Cloud Commerce environment at startup. Defaults to LiveEnvironment if not
//     // overridden; return TestEnvironment to run against MTF/Sandbox.
//     @Override
//     protected String getEnvironment() {
//         return ParameterValues.TestEnvironment; // or ParameterValues.LiveEnvironment
//     }
//
//     // Optional: react to TapToMobile setup. Always call super so ChipDnaApplication keeps
//     // tracking init state.
//     @Override
//     public void onSDKInitializationSuccess() {
//         super.onSDKInitializationSuccess();
//         Log.d("ChipDnaMobileDemo", "TapToMobile initialised");
//     }
//
//     @Override
//     public void onSDKInitializationFailed(String errorMessage) {
//         super.onSDKInitializationFailed(errorMessage);
//         Log.e("ChipDnaMobileDemo", "TapToMobile init failed: " + errorMessage);
//     }
// }
