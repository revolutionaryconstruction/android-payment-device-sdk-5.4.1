## ENABLING TAP TO MOBILE

This demo app only supports Payment device by default.
To set up Tap To Mobile follow the Payment Device SDK for Android - Tap To Mobile Supplement supplied along side this release. 
This will guide you through configuring an application to support Tap To Mobile.

Once this is done, there are several TODOs that preface commented code that will enable Tap To Mobile Transactions to be performed.

## ENABLING SMARTPOS INTEGRATION

By default this demo runs against the FULL ChipDNA SDK and connects to an external card reader over Bluetooth/USB.

It can also run directly ON an Axium SmartPOS terminal (on-device AAIO integration), where the SDK connects to the on-device payment service over TCP instead of to an external reader. To build the demo for this:

1. Replace `libs/ChipDnaMobile.jar` with the **Lite** build of the jar supplied by NMI. Keep the same filename — the build picks up every `*.jar` in `libs/`, so only one `ChipDnaMobile.jar` may be present. The external-reader driver jars (`bbdevice`, `Universal_SDK`) are not used on-device.
2. Set `minSdkVersion` to `29` in `build.gradle` (Axium devices run Android 10 / API 29).
3. Permit cleartext for the on-device SmartPOS REST link: add `android:usesCleartextTraffic="true"` to the `<application>` tag in `AndroidManifest.xml` (or a network-security-config permitting the loopback host). The on-device link is plain HTTP over loopback, so Android's default cleartext block (API 28+) otherwise makes `connectAndConfigure` fail with "CLEARTEXT communication not permitted".

SmartPOS integration is selected at initialization via the **"Is SmartPOS Integration"** checkbox on the password prompt. When the app detects it is running on an Axium terminal it forces this option on, skips the Bluetooth/USB pin-pad scan, and configures the on-device TCP connection automatically.