package com.creditcall.chipdnamobiledemo.util

import android.content.Context
import android.os.Build
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.creditcall.chipdnamobile.ChipDnaMobile
import com.creditcall.chipdnamobile.ParameterKeys
import com.creditcall.chipdnamobile.ParameterValues
import com.creditcall.chipdnamobile.Parameters
import kotlinx.coroutines.launch

//region ChipDnaMobile
fun getInstance(): ChipDnaMobile = ChipDnaMobile.getInstance()

fun isInstanceInitialized() = ChipDnaMobile.isInitialized()

fun ChipDnaMobile.getStatus(): Parameters = getInstance().getStatus(null)
//endregion

//region Parameters
fun Parameters.isSuccess() =
  containsKey(ParameterKeys.Result) && getValue(ParameterKeys.Result).equals(
    "True",
    ignoreCase = true
  )

fun Parameters.isPasswordAttemptReached() =
  getValue(ParameterKeys.RemainingAttempts)?.equals("0") ?: true

fun Parameters.isResponseRequired() =
  getValue(ParameterKeys.ResponseRequired) == ParameterValues.TRUE

fun Parameters.isOperatorPinRequired() =
  getValue(ParameterKeys.OperatorPinRequired) == ParameterValues.TRUE
//endregion


//region Fragment
fun Fragment.launchAndRepeatOnStarted(action: suspend () -> Unit) {
  viewLifecycleOwner.lifecycleScope.launch {
    repeatOnLifecycle(Lifecycle.State.STARTED) {
      action.invoke()
    }
  }
}
//endregion

//region Axium (AAIO) on-device detection
/**
 * Detects whether we are running ON an Axium (AAIO) SmartPOS device, i.e. the demo app and the
 * ChipDNA SDK are running directly on the payment terminal and talk to the local SmartPOS service
 * over a loopback TCP connection (no external/BLE pin pad).
 *
 * Detection is per tech-lead guidance using [Build.MANUFACTURER] / [Build.MODEL]: true when the
 * manufacturer contains "INGENICO" (case-insensitive) AND the model starts with one of the known
 * Axium model prefixes (e.g. "EX6000" -> "EX"). This list of prefixes may need extending as new
 * Axium models ship.
 */
fun isAxiumDevice(): Boolean {
  val manufacturer = Build.MANUFACTURER.orEmpty()
  val model = Build.MODEL.orEmpty()
  val isIngenico = manufacturer.contains("INGENICO", ignoreCase = true)
  // Known Axium model prefixes - extend as needed.
  val axiumModelPrefixes = listOf("EX", "DX", "RX")
  val isAxiumModel = axiumModelPrefixes.any { model.startsWith(it, ignoreCase = true) }
  return isIngenico && isAxiumModel
}
//endregion

fun View.show(show: Boolean = true) {
  visibility = if (show) {
    VISIBLE
  } else {
    GONE
  }
}